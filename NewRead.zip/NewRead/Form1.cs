﻿using FileOpera;
using Newtonsoft.Json;
using PMDEditor;
using Pmxfile;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace NewRead
{
    public partial class OpenForm : Form
    {
        public OpenForm()
        {
            InitializeComponent();
            ShowInfo = ShowInfoFun;
            Height = 140; Width = 464;
            this.TopMost = false;
            this.BringToFront();
            this.TopMost = true;
            GetDriveFile();
        }

        private string td_num;
        public static string BindataPath = Directory.CreateDirectory(Environment.GetFolderPath(Environment.SpecialFolder.InternetCache)).Parent.FullName;
        private string path = "";
        private string dispicurl = "";
        private string[] MODEL = new string[3];
        private Stream JsonStream;
        private List<string> DriveFile = new List<string>();
        private List<Data> ModelInfo = new List<Data>();
        private List<string> TexList = new List<string>();
        private List<string> DriveInfotemp = new List<string>();
        private bool scendsearch = true;

        public delegate void Showinfo(string value, int num);

        public Showinfo ShowInfo;

        public void ShowInfoFun(string text, int num)
        {
            switch (num)
            {
                case 10:
                    listBox1.Items.Clear();
                    Application.DoEvents();
                    break;

                case 0:
                    MessageLabel.Text = text;
                    Application.DoEvents();
                    break;

                case 1:
                    if (text != "" && text != null)
                    {
                        listBox1.Items.Add(text);
                        listBox1.SelectedIndex = listBox1.Items.Count - 1;
                    }
                    break;

                case 2:
                    if (text != "" && text != null)
                    {
                        listBox2.SelectedIndex = Convert.ToInt32(text);
                    }
                    break;

                case 3:
                    if (text != "" && text != null)
                    {
                        listBox3.Items.Add(text);
                        listBox3.SelectedIndex = listBox3.Items.Count - 1;
                    }
                    break;

                case 4:
                    Height = 140; Width = 464;
                    listBox1.Visible = false;
                    listBox2.Visible = false;
                    listBox3.Visible = false;
                    label1.Text = text;
                    label1.Visible = true;
                    MessageLabel.Text = "等待";
                    textBox1.Visible = true;
                    button1.Visible = true;
                    if (text == "无法找到模型，请用IE浏览器加载完毕模型后再继续")
                    {
                        System.Diagnostics.Process.Start("iexplore.exe", @"3d.nicovideo.jp/externals/embedded?id=td" + td_num);
                    }
                    Application.DoEvents();
                    break;

                case 5:
                    toolStripProgressBar1.Value++;
                    break;

                case 55:
                    toolStripProgressBar1.Maximum = Convert.ToInt32(text);
                    toolStripProgressBar1.Value = 0;
                    break;

                case 6:
                    listBox1.Visible = false;
                    listBox2.Visible = true;
                    listBox3.Visible = true;
                    foreach (Data temp in ModelInfo)
                    {
                        listBox2.Items.Add(temp.texname);
                    }
                    listBox2.SelectedIndex = 0;
                    break;

                case 7:
                    label1.Visible = false;
                    textBox1.Visible = false;
                    button1.Visible = false;
                    Height = 240; Width = 624;
                    listBox1.Visible = true;
                    break;

                case 33:
                    listBox3.Items.Clear();
                    break;
            }
        }

        private class jsondata
        {
            public string Path;
            public string Value;

            public jsondata(string path, object value)
            {
                this.Path = path;
                if (value != null)
                {
                    this.Value = value.ToString();
                }
                else { this.Value = ""; }
            }
        }

        public class CGMLZMA
        {
            private uint x;
            private uint y;
            private uint z;
            private uint w;

            public CGMLZMA(int seed)
            {
                this.x = (uint)seed;
                this.y = 362436069u;
                this.z = 521288629u;
                this.w = 88675123u;
            }

            public uint NextUInt32()
            {
                uint num = this.x ^ this.x << 11;
                this.x = this.y;
                this.y = this.z;
                this.z = this.w;
                return this.w = (this.w ^ this.w >> 19 ^ (num ^ num >> 8));
            }
        }

        private class Data
        {
            public string path;
            public string value;
            public string texname;
            public string texurl0;
            public string texurl1;

            public Data(string path, object value)
            {
                this.path = path;
                if (value != null)
                {
                    this.value = value.ToString();
                }
                else
                {
                    this.value = "";
                }
            }

            public Data(string path, string value, string v)
            {
                texname = path;
                texurl0 = value;
                texurl1 = v;
            }

            public static string Urlname { get; internal set; }
        }

        private void GetDriveInfo()
        {
            startGetDriveFile = true;

            DriveInfotemp.AddRange((new DriveInfo(BindataPath)).EnumerateFiles().ToArray());
            foreach (string Temp in DriveInfotemp)
            {
                if (Temp.Contains(BindataPath))
                {
                    DriveFile.Add(Temp);
                }
            }
            startGetDriveFile = false;
        }

        private bool startGetDriveFile = false;

        private void GetDriveFile()
        {
            ThreadStart ts = new ThreadStart(GetDriveInfo);
            Thread th = new Thread(ts);
            th.Start();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TexList.Clear();
            ModelInfo.Clear();
            MODEL = new string[3];
            if (startGetDriveFile != true)
            {
                DriveFile.Clear();
                GetDriveFile();
            }
            try
            {
                string[] downloadsArr = textBox1.Text.Split(Convert.ToChar("d"));
                int.Parse(downloadsArr[downloadsArr.Length - 1]);
                td_num = downloadsArr[downloadsArr.Length - 1];
            }
            catch (Exception)
            {
                MessageBox.Show("输入的网址有误", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            FolderBrowserDialog save = new FolderBrowserDialog();
            save.ShowNewFolderButton = true;
            save.Description = "请选择保存目录";
            for (; true;)
            {
                save.ShowDialog();
                if (save.SelectedPath != "")
                {
                    break;
                }
            }
            Thread newThread = new Thread(new ThreadStart(Start));
            newThread.SetApartmentState(ApartmentState.STA);
            path = save.SelectedPath;
            if (Downloadjson())
            {
                newThread.Start();
            }
        }

        private void Start()
        {
            Invoke(ShowInfo, "", 7);
            Thread newThread = new Thread(new ThreadStart(AnalyseModel));
            newThread.SetApartmentState(ApartmentState.MTA);
            if (AnalyseJson())
            {
                if (MessageLabel.Text == "Json反序列化成功")
                {
                    Invoke(ShowInfo, "", 10);
                    Invoke(ShowInfo, DriveFile.Count.ToString(), 55);
                    newThread.Start();
                }
            }
        }

        private void CopyTex()
        {
            try
            {
                Invoke(ShowInfo, "", 6);
                Invoke(ShowInfo, "正在搜索并复制贴图", 0);
                Invoke(ShowInfo, ModelInfo.Count.ToString(), 55);

                for (int j = 0; j < ModelInfo.Count; j++)
                {
                    Invoke(ShowInfo, j.ToString(), 2);
                    Invoke(ShowInfo, ModelInfo.Count.ToString(), 5);
                    Thread newThread = new Thread(new ThreadStart(ShowSearch));
                    newThread.SetApartmentState(ApartmentState.MTA);
                    if ((new FileInfo(path + @"\" + ModelInfo[j].texname).Exists != true))
                    {
                        newThread.Start();
                        for (int x = 0; x < DriveFile.Count; x++)
                        {
                            try
                            {
                                FileInfo newfile = new FileInfo(DriveFile[x]);
                                if (newfile.Name == ModelInfo[j].texurl0 + "." + ModelInfo[j].texurl1)
                                {
                                    Thread.Sleep(500);
                                    newThread.Abort();
                                    string Addpath = "";
                                    if (TexList != null)
                                    {
                                        foreach (string temp in TexList)
                                        {
                                            string[] TEMP = temp.Split(new char[] { '\\' });
                                            if (TEMP.Length != 1)
                                            {
                                                if (TEMP[1] == ModelInfo[j].texname)
                                                {
                                                    {
                                                        if (Directory.Exists(path + @"\" + TEMP[0]) == false)
                                                        {
                                                            DirectoryInfo dir = new DirectoryInfo(path);
                                                            dir.CreateSubdirectory(TEMP[0]);
                                                        }
                                                        Addpath = temp;
                                                        break;
                                                    }
                                                }
                                            }
                                            else
                                            {
                                            }
                                        }
                                    }
                                    if (Addpath != "")
                                    {
                                        File.Copy(newfile.FullName, path + @"\" + Addpath, true);
                                    }
                                    else
                                    {
                                        File.Copy(newfile.FullName, path + @"\" + ModelInfo[j].texname, true);
                                    }
                                    break;
                                }
                            }
                            catch (Exception) { }
                        }
                    }
                    else
                    {
                        newThread.Abort();
                    }
                }
            }
            catch (Exception) { }
            try
            {
                Invoke(ShowInfo, "模型解析完毕", 4);
            }
            catch (Exception) { }
        }

        public void AnalyseModel()
        {
            try
            {
                Invoke(ShowInfo, "正在搜索模型", 0);
                Thread newThread = new Thread(new ThreadStart(ShowModelSearch));
                newThread.SetApartmentState(ApartmentState.MTA);
                newThread.Start();
                for (int i = 0; i < DriveFile.Count; i++)
                {
                    try
                    {
                        int timeout = 0;
                        string saveextsion = null;
                        if (new FileInfo(DriveFile[i]).Name == MODEL[1] + "." + MODEL[2])
                        {
                            Thread.Sleep(1000);
                            newThread.Abort();
                            Invoke(ShowInfo, DriveInfotemp[i], 1);
                            Invoke(ShowInfo, "正在解析模型", 0);
                            switch (MODEL[2])
                            {
                                case "plg": timeout = 33249; saveextsion = "mqo"; break;
                                case "xs3": timeout = 80128; saveextsion = "pmx"; break;
                                case "mod": timeout = 27731; saveextsion = "obj"; break;
                                case "plgx": timeout = 114514; saveextsion = "pmd"; break;
                                case "ncsc": timeout = 215191; saveextsion = "cscu"; break;
                                case "plm": timeout = 536900; saveextsion = "plm"; break;
                            }
                            byte[] file = File.ReadAllBytes(new FileInfo(DriveFile[i]).FullName);
                            CGMLZMA cGMLZMA = new CGMLZMA(file.Length ^ timeout);
                            using (MemoryStream memoryStream = new MemoryStream(file))
                            {
                                using (MemoryStream memoryStream2 = new MemoryStream())
                                {
                                    while (true)
                                    {
                                        int num = (int)Math.Min(memoryStream.Length - memoryStream.Position, 4L);
                                        if (num <= 0)
                                        {
                                            break;
                                        }
                                        byte[] array = new byte[4];
                                        memoryStream.Read(array, 0, num);
                                        if (num == 4)
                                        {
                                            uint num2 = BitConverter.ToUInt32(array, 0) ^ cGMLZMA.NextUInt32();
                                            array = BitConverter.GetBytes(num2);
                                        }
                                        memoryStream2.Write(array, 0, num);
                                    }
                                    try
                                    {
                                        memoryStream2.Position = 0L;
                                        if (saveextsion == "pmx")
                                        {
                                            Pmx pmxfile = PmxFile.FromStream(memoryStream2, null);
                                            for (int x = 0; x < pmxfile.MaterialList.Count; x++)
                                            {
                                                bool add = true;
                                                if (pmxfile.MaterialList[x].Tex != "")
                                                {
                                                    add = true;
                                                    foreach (string temp in TexList)
                                                    {
                                                        if (temp == pmxfile.MaterialList[x].Tex)
                                                        {
                                                            add = false;
                                                        }
                                                    }
                                                    if (add)
                                                    {
                                                        TexList.Add(pmxfile.MaterialList[x].Tex);
                                                    }
                                                }
                                                if (pmxfile.MaterialList[x].Sphere != "")
                                                {
                                                    add = true;
                                                    foreach (string temp in TexList)
                                                    {
                                                        if (temp == pmxfile.MaterialList[x].Sphere)
                                                        {
                                                            add = false;
                                                        }
                                                    }
                                                    if (add)
                                                    {
                                                        TexList.Add(pmxfile.MaterialList[x].Sphere);
                                                    }
                                                }
                                                if (pmxfile.MaterialList[x].Toon != "")
                                                {
                                                    add = true;
                                                    foreach (string temp in TexList)
                                                    {
                                                        if (temp == pmxfile.MaterialList[x].Toon)
                                                        {
                                                            add = false;
                                                        }
                                                    }
                                                    if (add)
                                                    {
                                                        TexList.Add(pmxfile.MaterialList[x].Toon);
                                                    }
                                                }
                                            }
                                        }
                                        else if (saveextsion == "pmd")
                                        {
                                            PmdFile.Pmd.MMDModel pmdfile = new PmdFile.Pmd.MMDModel(memoryStream2, 1.0f);
                                            for (int x = 0; x < pmdfile.Materials.Length; x++)
                                            {
                                                bool add = true;
                                                if (pmdfile.Materials[x].TextureFileName != "")
                                                {
                                                    add = true;
                                                    foreach (string temp in TexList)
                                                    {
                                                        if (temp == pmdfile.Materials[x].TextureFileName)
                                                        {
                                                            add = false;
                                                        }
                                                    }
                                                    if (add)
                                                    {
                                                        TexList.Add(pmdfile.Materials[x].TextureFileName);
                                                    }
                                                }
                                                if (pmdfile.Materials[x].SphereTextureFileName != "")
                                                {
                                                    add = true;
                                                    foreach (string temp in TexList)
                                                    {
                                                        if (temp == pmdfile.Materials[x].SphereTextureFileName)
                                                        {
                                                            add = false;
                                                        }
                                                    }
                                                    if (add)
                                                    {
                                                        TexList.Add(pmdfile.Materials[x].SphereTextureFileName);
                                                    }
                                                }
                                            }
                                            for (int x = 0; x < pmdfile.ToonFileNames.Count; x++)
                                            {
                                                bool add = true;
                                                if (pmdfile.ToonFileNames[x] != "")
                                                {
                                                    add = true;
                                                    foreach (string temp in TexList)
                                                    {
                                                        if (temp == pmdfile.ToonFileNames[x])
                                                        {
                                                            add = false;
                                                        }
                                                    }
                                                    if (add)
                                                    {
                                                        TexList.Add(pmdfile.ToonFileNames[x]);
                                                    }
                                                }
                                            }
                                        }
                                        string filename = path + @"\" + MODEL[0] + "." + saveextsion;
                                        FileStream fs = new FileStream(filename, FileMode.OpenOrCreate);
                                        BinaryWriter w = new BinaryWriter(fs);
                                        w.Write(memoryStream2.ToArray());
                                        fs.Close();
                                        Invoke(ShowInfo, "模型解析成功", 0);
                                        ThreadStart ts = new ThreadStart(CopyTex);
                                        Thread th = new Thread(ts);
                                        th.Start();
                                        break;
                                    }
                                    catch (Exception)
                                    {
                                    }
                                }
                            }
                        }
                    }
                    catch (Exception) { }
                    if (i == DriveFile.Count - 1)
                    {
                        newThread.Abort();
                        if (scendsearch)
                        {
                            scendsearch = false;
                            DriveFile = new List<string>(DriveInfotemp);
                            AnalyseModel();
                        }
                        else
                        {
                            Invoke(ShowInfo, "无法找到模型，请用IE浏览器加载完毕模型后再继续", 4);
                        }

                        break;
                    }
                }
            }
            catch (Exception) { }
        }

        private void ShowModelSearch()
        {
            foreach (string dir in DriveInfotemp)
            {
                listBox1.Invoke(ShowInfo, dir, 1);
            }
        }

        private void ShowSearch()
        {
            try
            {
                Invoke(ShowInfo, "", 33);
                foreach (string dir in DriveInfotemp)
                {
                    Invoke(ShowInfo, dir, 3);
                }
            }
            catch (Exception) { }
        }

        private bool AnalyseJson()
        {
            try
            {
                Invoke(ShowInfo, "正在解析Json数据", 0);
                {
                    bool restex = false;
                    int count = 0;
                    JsonReader reader = new JsonTextReader(new StringReader(new StreamReader(JsonStream, Encoding.GetEncoding("utf-8")).ReadToEnd()));//无论如何 都从服务器取得一份json
                    List<Data> Modelinfo = new List<Data>();
                    List<jsondata> temp = new List<jsondata>();
                    string[] Texname = new string[1000];
                    string[] Urlname = new string[1000];
                    string[] Urlest = new string[1000];
                    while (reader.Read())
                    { temp.Add(new jsondata(reader.Path, reader.Value)); }
                    Invoke(ShowInfo, temp.Count.ToString(), 55);
                    foreach (jsondata Temp in temp)
                    {
                        Invoke(ShowInfo, "", 5);
                        Invoke(ShowInfo, Temp.Path + "\t" + Temp.Value, 1);
                        string stra = (string)Temp.Path;
                        string getname = Convert.ToString(Temp.Value);
                        string[] sArr = stra.Split(new char[] { '.' });
                        if (restex)
                        {
                            foreach (string s in sArr)
                            {
                                if (s.Equals("url"))
                                {
                                    if (getname != "url")
                                    {
                                        string[] urlname = getname.Split(new char[] { '/' });
                                        string[] texname = urlname[6].Split(new char[] { '.' });
                                        Urlname[count] = texname[0] + "[1]";
                                        Urlest[count] = texname[1];
                                        count++;
                                        restex = false;
                                    }
                                }
                            }
                        }
                        foreach (string s in sArr)
                        {
                            if (s.Equals("name"))
                            {
                                if (getname != "name")
                                {
                                    Texname[count] = getname;
                                    restex = true;
                                }
                            }
                        }

                        if (stra == "work.title")
                        {
                            if (getname != "title")
                            {
                                MODEL[0] = getname;
                                DirectoryInfo dir = new DirectoryInfo(path);
                                dir.CreateSubdirectory(getname);
                                path = path + @"\" + getname;
                                if ((new FileInfo(path + @"\" + @"folder.jpg").Exists) == false)
                                {
                                    if (dispicurl != "")
                                    {
                                        Thread newThread = new Thread(new ThreadStart(Downloaddispic));
                                        newThread.SetApartmentState(ApartmentState.STA);
                                        newThread.Start();
                                    }
                                }
                            }
                        }
                        if (stra == "components[0].url")
                        {
                            if (getname != "url")
                            {
                                string[] name = getname.Split(new char[] { '/' })[6].Split(new char[] { '.' });
                                MODEL[1] = name[0] + "[1]";//模型全的乱码
                                MODEL[2] = name[1];//模型的后缀
                            }
                        }
                        if (stra == "components[0].display_url")
                        {
                            if (getname != "display_url")
                            {
                                dispicurl = getname;
                            }
                        }
                    }
                    for (int i = 0; i < count; i++)
                    {
                        bool add = true;
                        if (Texname[i] != null)
                        {
                            foreach (Data TEmp in ModelInfo)
                            {
                                if (TEmp.texname == Texname[i])
                                {
                                    add = false;
                                }
                            }
                            if (add)
                            {
                                ModelInfo.Add(new Data(Texname[i], Urlname[i], Urlest[i]));
                            }
                        }
                    }
                }
            }
            catch (Exception) { try { this.Invoke(ShowInfo, "Json解析失败，请重试", 4); } catch (Exception) { } return false; }
            Invoke(ShowInfo, "Json反序列化成功", 0);
            return true;
        }

        private void Downloaddispic()
        {
            WebClient client = new WebClient();
            client.DownloadFile(dispicurl, path + @"\" + @"folder.jpg");
        }

        private bool Downloadjson()
        {
            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create("http://3d.nicovideo.jp/works/td" + td_num + "/components.json");
                request.Method = "GET";
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                JsonStream = response.GetResponseStream();
                return true;
            }
            catch (Exception) { label1.Text = "下载配置数据错误，请检查地址的正确性再重试"; }
            return false;

            /*  try
              {
                  if (new FileInfo(Jsonpath).Exists)
                  {
                      File.Delete(Jsonpath);
                  }
                  WebClient client = new WebClient();
                  client.DownloadFile("http://3d.nicovideo.jp/works/td" + td_num + "/components.json", Jsonpath);
                  return true;
              }
              catch (Exception)
              {
                  this.Invoke(Changeform, "Json下载失败，请确认后重试");
              }*/
        }
    }
}